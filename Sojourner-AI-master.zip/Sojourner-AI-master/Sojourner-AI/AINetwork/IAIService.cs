﻿using Sojourner_AI.AINetwork;
using System.Threading.Tasks;

namespace Sojourner_AI
{
    public interface IAIService
    {
        Task<ChatResponse> ProcessRequest(string input);
    }
}