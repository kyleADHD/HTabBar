﻿using System.Numerics;
using Microsoft.Data.Sqlite;
using System.Text;
using System.Security.Cryptography;
using Microsoft.ML;
using Microsoft.ML.Transforms.Text;
using Microsoft.Extensions.Logging;
using System.Windows.Forms;
using System.IO;
using Microsoft.ML.Data;

namespace Sojourner_AI.AINetwork
{
    public class Document
    {
        public string Id { get; set; }
        public string Content { get; set; }
        public string Type { get; set; }  // code, documentation, conversation, etc.
        public string Metadata { get; set; }
        public DateTime Created { get; set; }
        public float[] Vector { get; set; }

        public Document()
        {
            Id = Guid.NewGuid().ToString();
            Created = DateTime.UtcNow;
        }
    }

    public class RAGService : IDisposable
    {
        private readonly ILogger<RAGService> _logger;
        private readonly SqliteConnection _connection;
        private readonly MLContext _mlContext;
        private ITransformer _vectorizer;
        private const int VectorSize = 768; // Default size for many embeddings

        public RAGService(ILogger<RAGService> logger, string dbPath)
        {
            _logger = logger;
            _mlContext = new MLContext(seed: 42);
            _connection = new SqliteConnection($"Data Source={dbPath}");
            InitializeDatabase().Wait();
            InitializeVectorizer();
        }

        private async Task InitializeDatabase()
        {
            await _connection.OpenAsync();

            // Create tables if they don't exist
            using var command = _connection.CreateCommand();
            command.CommandText = @"
                CREATE TABLE IF NOT EXISTS Documents (
                    Id TEXT PRIMARY KEY,
                    Content TEXT NOT NULL,
                    Type TEXT NOT NULL,
                    Metadata TEXT,
                    Created DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS Vectors (
                    DocumentId TEXT PRIMARY KEY,
                    Vector BLOB NOT NULL,
                    FOREIGN KEY(DocumentId) REFERENCES Documents(Id)
                );

                CREATE VIRTUAL TABLE IF NOT EXISTS DocumentsFTS USING fts5(
                    Content,
                    Type,
                    Metadata,
                    content='Documents'
                );

                CREATE TABLE IF NOT EXISTS Embeddings (
                    Id TEXT PRIMARY KEY,
                    Vector BLOB NOT NULL
                );";

            await command.ExecuteNonQueryAsync();
        }

        private void InitializeVectorizer()
        {
            // Create a simple ML.NET pipeline for text vectorization
            var pipeline = _mlContext.Transforms.Text.NormalizeText("NormalizedText",
                    keepDiacritics: false,
                    keepPunctuations: false,
                    keepNumbers: true)
                .Append(_mlContext.Transforms.Text.TokenizeIntoWords("Words", "NormalizedText"))
                .Append(_mlContext.Transforms.Text.RemoveDefaultStopWords("FilteredWords", "Words"))
                .Append(_mlContext.Transforms.Text.ProduceNgrams("Ngrams", "FilteredWords"))
                .Append(_mlContext.Transforms.Conversion.MapValueToKey("Labels", "FilteredWords"))
                .Append(_mlContext.Transforms.Text.ProduceWordEmbeddings("Features", "FilteredWords",
                    wordVectorsPath: Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wordvectors.bin")));

            // Create an empty dataset to train the pipeline
            var emptyData = _mlContext.Data.LoadFromEnumerable(new[] { new { Text = string.Empty } });
            _vectorizer = pipeline.Fit(emptyData);
        }

        public async Task AddDocument(string content, string type, string metadata = null)
        {
            try
            {
                var document = new Document
                {
                    Content = content,
                    Type = type,
                    Metadata = metadata
                };

                // Generate vector embedding
                document.Vector = GenerateEmbedding(content);

                using var transaction = _connection.BeginTransaction();

                // Insert document
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.Transaction = transaction;
                    cmd.CommandText = @"
                        INSERT INTO Documents (Id, Content, Type, Metadata)
                        VALUES (@id, @content, @type, @metadata)";

                    cmd.Parameters.AddWithValue("@id", document.Id);
                    cmd.Parameters.AddWithValue("@content", document.Content);
                    cmd.Parameters.AddWithValue("@type", document.Type);
                    cmd.Parameters.AddWithValue("@metadata", document.Metadata ?? (object)DBNull.Value);

                    await cmd.ExecuteNonQueryAsync();
                }

                // Insert vector
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.Transaction = transaction;
                    cmd.CommandText = @"
                        INSERT INTO Vectors (DocumentId, Vector)
                        VALUES (@docId, @vector)";

                    cmd.Parameters.AddWithValue("@docId", document.Id);
                    cmd.Parameters.AddWithValue("@vector", document.Vector);

                    await cmd.ExecuteNonQueryAsync();
                }

                // Update FTS table
                using (var cmd = _connection.CreateCommand())
                {
                    cmd.Transaction = transaction;
                    cmd.CommandText = @"
                        INSERT INTO DocumentsFTS (Content, Type, Metadata)
                        VALUES (@content, @type, @metadata)";

                    cmd.Parameters.AddWithValue("@content", document.Content);
                    cmd.Parameters.AddWithValue("@type", document.Type);
                    cmd.Parameters.AddWithValue("@metadata", document.Metadata ?? (object)DBNull.Value);

                    await cmd.ExecuteNonQueryAsync();
                }

                await transaction.CommitAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding document to RAG store");
                throw;
            }
        }

        public async Task<List<Document>> Search(string query, int k = 3)
        {
            try
            {
                var queryVector = GenerateEmbedding(query);
                var results = new List<Document>();

                // Combine semantic and keyword search
                using var command = _connection.CreateCommand();
                command.CommandText = @"
                    WITH SemanticMatches AS (
                        SELECT 
                            d.Id,
                            d.Content,
                            d.Type,
                            d.Metadata,
                            d.Created,
                            VectorDistance(v.Vector, @queryVector) as semantic_score
                        FROM Documents d
                        JOIN Vectors v ON d.Id = v.DocumentId
                    ),
                    KeywordMatches AS (
                        SELECT 
                            d.Id,
                            d.Content,
                            d.Type,
                            d.Metadata,
                            d.Created,
                            rank as keyword_score
                        FROM DocumentsFTS fts
                        JOIN Documents d ON d.rowid = fts.rowid
                        WHERE DocumentsFTS MATCH @query
                    )
                    SELECT 
                        COALESCE(k.Id, s.Id) as Id,
                        COALESCE(k.Content, s.Content) as Content,
                        COALESCE(k.Type, s.Type) as Type,
                        COALESCE(k.Metadata, s.Metadata) as Metadata,
                        COALESCE(k.Created, s.Created) as Created,
                        COALESCE(k.keyword_score, 1.0) * COALESCE(s.semantic_score, 1.0) as combined_score
                    FROM SemanticMatches s
                    FULL OUTER JOIN KeywordMatches k ON s.Id = k.Id
                    ORDER BY combined_score DESC
                    LIMIT @limit";

                command.Parameters.AddWithValue("@queryVector", queryVector);
                command.Parameters.AddWithValue("@query", query);
                command.Parameters.AddWithValue("@limit", k);

                using var reader = await command.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    results.Add(new Document
                    {
                        Id = reader.GetString(0),
                        Content = reader.GetString(1),
                        Type = reader.GetString(2),
                        Metadata = reader.IsDBNull(3) ? null : reader.GetString(3),
                        Created = reader.GetDateTime(4)
                    });
                }

                return results;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching RAG store");
                throw;
            }
        }

        private float[] GenerateEmbedding(string text)
        {
            // Create input data
            var data = _mlContext.Data.LoadFromEnumerable(new[] { new { Text = text } });

            // Transform data using the pipeline
            var transformedData = _vectorizer.Transform(data);

            // Get the embedding
            var embedding = transformedData.GetColumn<float[]>("Features").First();

            // Normalize the embedding
            var magnitude = (float)Math.Sqrt(embedding.Sum(x => x * x));
            return embedding.Select(x => x / magnitude).ToArray();
        }

        private float VectorDistance(float[] v1, float[] v2)
        {
            // Cosine similarity
            float dotProduct = 0;
            for (int i = 0; i < v1.Length; i++)
            {
                dotProduct += v1[i] * v2[i];
            }
            return dotProduct;
        }

        public void Dispose()
        {
            _connection?.Dispose();
        }
    }
}