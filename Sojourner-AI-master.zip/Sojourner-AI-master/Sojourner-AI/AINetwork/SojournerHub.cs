﻿using System;
using System.Collections.Generic;

namespace Sojourner_AI
{
    public class SojournerHub
    {
        private readonly Dictionary<string, IAIService> _services = new Dictionary<string, IAIService>();

        public void RegisterService(string serviceName, IAIService service)
        {
            _services[serviceName] = service;
        }

        public IAIService GetService(string serviceName)
        {
            if (_services.TryGetValue(serviceName, out var service))
            {
                return service;
            }
            throw new ArgumentException($"Service '{serviceName}' is not registered.");
        }
    }
}