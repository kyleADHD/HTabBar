﻿using Microsoft.Extensions.Logging;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HtmlAgilityPack;
using System.Linq;
using System.Collections.Generic;

public class WebViewScraperService : IAsyncDisposable
{
    private readonly ILogger _logger;
    private WebView2 _webView;
    private readonly Border _displayBorder;
    private readonly TextBlock _titleLabel;
    private readonly Border _container;
    private readonly Grid _loadingGrid;
    private readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1);
    private TaskCompletionSource<string> _navigationCompletionSource;

    public WebViewScraperService(ILogger logger, Border webViewDisplay, TextBlock webViewTitle,
                                Border webViewContainer, Grid loadingGrid)
    {
        _logger = logger;
        _displayBorder = webViewDisplay;
        _titleLabel = webViewTitle;
        _container = webViewContainer;
        _loadingGrid = loadingGrid;
    }

    private async Task InitializeWebView()
    {
        await Application.Current.Dispatcher.InvokeAsync(async () =>
        {
            try
            {
                _displayBorder.Visibility = Visibility.Visible;
                _loadingGrid.Visibility = Visibility.Visible;
                _container.Visibility = Visibility.Visible;

                _webView = new WebView2();
                await _webView.EnsureCoreWebView2Async();
                _webView.DefaultBackgroundColor = System.Drawing.Color.FromArgb(45, 45, 48);
                _container.Child = _webView;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initialize WebView2");
                throw;
            }
        });
    }

    public async Task<string> ScrapeWebPageAsync(string url)
    {
        try
        {
            await _semaphore.WaitAsync();
            _navigationCompletionSource = new TaskCompletionSource<string>();

            await InitializeWebView();

            // Set up event handler before navigation
            _webView.NavigationCompleted += WebView_NavigationCompleted;

            // Start navigation
            await Application.Current.Dispatcher.InvokeAsync(() =>
            {
                _webView.Source = new Uri(url);
            });

            // Wait for completion with timeout
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            var completionTask = _navigationCompletionSource.Task;

            var timeoutTask = Task.Delay(TimeSpan.FromSeconds(30), cts.Token);
            var completedTask = await Task.WhenAny(completionTask, timeoutTask);

            if (completedTask == timeoutTask)
            {
                throw new TimeoutException("WebView scraping timed out");
            }

            return await completionTask;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Failed to scrape {url}");
            throw;
        }
        finally
        {
            _semaphore.Release();
            await CleanupWebView();
        }
    }

    private async void WebView_NavigationCompleted(object sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationCompletedEventArgs e)
    {
        try
        {
            if (!e.IsSuccess)
            {
                _navigationCompletionSource?.TrySetException(new Exception($"Navigation failed with error: {e.WebErrorStatus}"));
                return;
            }

            await Application.Current.Dispatcher.InvokeAsync(async () =>
            {
                try
                {
                    _loadingGrid.Visibility = Visibility.Collapsed;
                    _container.Visibility = Visibility.Visible;
                    _titleLabel.Text = $"Viewing: {_webView.Source.Host}";

                    // Wait for page to settle
                    await Task.Delay(1000);

                    var html = await _webView.ExecuteScriptAsync(
                        "document.documentElement.outerHTML"
                    );

                    var doc = new HtmlDocument();
                    doc.LoadHtml(html.Trim('"'));

                    var content = doc.DocumentNode.SelectNodes("//body//text()")
                        ?.Select(node => node.InnerText.Trim())
                        .Where(text => !string.IsNullOrWhiteSpace(text))
                        .Aggregate(new StringBuilder(), (sb, text) => sb.AppendLine(text))
                        .ToString();

                    _navigationCompletionSource?.TrySetResult(content ?? "No content found");
                }
                catch (Exception ex)
                {
                    _navigationCompletionSource?.TrySetException(ex);
                }
            });
        }
        catch (Exception ex)
        {
            _navigationCompletionSource?.TrySetException(ex);
        }
        finally
        {
            // Remove the event handler
            if (sender is WebView2 webView)
            {
                webView.NavigationCompleted -= WebView_NavigationCompleted;
            }
        }
    }

    private async Task CleanupWebView()
    {
        await Application.Current.Dispatcher.InvokeAsync(() =>
        {
            if (_webView != null)
            {
                _container.Child = null;
                _webView.Dispose();
                _webView = null;
            }
            _displayBorder.Visibility = Visibility.Collapsed;
            _container.Visibility = Visibility.Collapsed;
        });
    }

    public async ValueTask DisposeAsync()
    {
        await CleanupWebView();
    }
}