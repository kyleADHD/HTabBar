﻿using System;

namespace Sojourner_AI
{
    public class AIModel
    {
        public string ModelId { get; set; }
        public string ShortName { get; set; }
        public string Description { get; set; }

        public AIModel(string modelId, string shortName, string description)
        {
            ModelId = modelId;
            ShortName = shortName;
            Description = description;
        }

        public override string ToString()
        {
            return ShortName;
        }
    }
}