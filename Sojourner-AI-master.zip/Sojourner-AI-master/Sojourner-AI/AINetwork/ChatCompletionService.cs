﻿//using System;
//using System.Net.Http;
//using System.Text;
//using System.Threading.Tasks;
//using Newtonsoft.Json;
//using Newtonsoft.Json.Linq;
//using System.Collections.Generic;
//using Microsoft.Extensions.Logging;
//using System.Linq;
//using System.Threading;
//using System.Windows;

//namespace Sojourner_AI.AINetwork
//{
//    public class ChatCompletionService : IAIService, IAsyncDisposable
//    {
//        private readonly HttpClient _httpClient;
//        private readonly string _modelId;
//        private readonly ILogger _logger;
//        private readonly WebViewScraperService _webScraperService;
//        private readonly List<object> _conversationHistory;
//        private const string BaseUrl = "https://api-inference.huggingface.co/models/";
//        private const string ImageModelId = "black-forest-labs/FLUX.1-dev";
//        private const int MaxNewTokens = 1000;

//        public ChatCompletionService(string modelId, string apiKey, ILogger logger)
//        {
//            _modelId = modelId;
//            _logger = logger;
//            _conversationHistory = new List<object>();

//            // Initialize WebView components
//            var mainWindow = Application.Current.MainWindow;
//            var webViewDisplay = mainWindow.FindName("WebViewDisplay") as System.Windows.Controls.Border;
//            var webViewTitle = mainWindow.FindName("WebViewTitle") as System.Windows.Controls.TextBlock;
//            var webViewContainer = mainWindow.FindName("WebViewContainer") as System.Windows.Controls.Border;
//            var loadingGrid = mainWindow.FindName("LoadingGrid") as System.Windows.Controls.Grid;

//            if (webViewDisplay == null || webViewTitle == null ||
//                webViewContainer == null || loadingGrid == null)
//            {
//                throw new InvalidOperationException("Required WebView UI elements not found");
//            }

//            _webScraperService = new WebViewScraperService(
//                logger: logger,
//                webViewDisplay: webViewDisplay,
//                webViewTitle: webViewTitle,
//                webViewContainer: webViewContainer,
//                loadingGrid: loadingGrid
//            );

//            _httpClient = new HttpClient { Timeout = TimeSpan.FromMinutes(5) };
//            _httpClient.DefaultRequestHeaders.Authorization =
//                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", apiKey);
//            _httpClient.DefaultRequestHeaders.Add("x-wait-for-model", "true");
//        }

//        public async Task<ChatResponse> ProcessRequest(string input)
//        {
//            try
//            {
//                if (input.StartsWith("Generate an image:", StringComparison.OrdinalIgnoreCase))
//                {
//                    string imagePrompt = input.Substring("Generate an image:".Length).Trim();
//                    string imageData = await GenerateImage(imagePrompt);
//                    return new ChatResponse
//                    {
//                        Content = $"Image generated based on prompt: {imagePrompt}",
//                        ImageData = imageData
//                    };
//                }
//                else if (input.StartsWith("Search:", StringComparison.OrdinalIgnoreCase))
//                {
//                    return await HandleWebSearch(input);
//                }
//                else
//                {
//                    var chatResponse = await ProcessChatRequest(input);
//                    UpdateConversationHistory(input, chatResponse.Content);
//                    return chatResponse;
//                }
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, "Error processing request");
//                return new ChatResponse
//                {
//                    Content = "I encountered an error. Please try again or rephrase your question."
//                };
//            }
//        }

//        private async Task<ChatResponse> ProcessChatRequest(string input)
//        {
//            try
//            {
//                var endpoint = $"{BaseUrl}{_modelId}";

//                var messages = BuildMessageHistory(input);

//                var payload = new
//                {
//                    messages = messages,
//                    temperature = 0.5,
//                    top_p = 0.9,
//                    max_tokens = MaxNewTokens,
//                    stream = false,
//                    frequency_penalty = 0.3, // Reduces repetition
//                    presence_penalty = 0.3   // Encourages new topics
//                };

//                var content = new StringContent(
//                    JsonConvert.SerializeObject(payload),
//                    Encoding.UTF8,
//                    "application/json"
//                );

//                var response = await _httpClient.PostAsync(endpoint, content);
//                var responseBody = await response.Content.ReadAsStringAsync();

//                if (!response.IsSuccessStatusCode)
//                {
//                    _logger.LogError($"API Error: {response.StatusCode}, {responseBody}");
//                    return new ChatResponse
//                    {
//                        Content = "Sorry, I'm having trouble processing your request right now."
//                    };
//                }

//                var jsonResponse = JObject.Parse(responseBody);
//                var generatedText = jsonResponse["choices"]?[0]?["message"]?["content"]?.ToString().Trim();

//                if (string.IsNullOrEmpty(generatedText))
//                {
//                    return new ChatResponse
//                    {
//                        Content = "I couldn't generate a proper response. Please try again."
//                    };
//                }

//                return new ChatResponse { Content = generatedText };
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, "Error in ProcessChatRequest");
//                return new ChatResponse
//                {
//                    Content = "An error occurred while processing your request."
//                };
//            }
//        }

//        private List<object> BuildMessageHistory(string newInput)
//        {
//            var messages = new List<object>
//            {
//                new
//                {
//                    role = "system",
//                    content = "You are a helpful AI assistant. Be concise for simple questions. " +
//                             "Provide detailed responses only when necessary. Always be accurate and helpful."
//                }
//            };

//            // Add recent conversation history (last 5 messages)
//            messages.AddRange(_conversationHistory.TakeLast(5));

//            // Add the new user message
//            messages.Add(new
//            {
//                role = "user",
//                content = newInput
//            });

//            return messages;
//        }

//        private void UpdateConversationHistory(string userInput, string assistantResponse)
//        {
//            _conversationHistory.Add(new { role = "user", content = userInput });
//            _conversationHistory.Add(new { role = "assistant", content = assistantResponse });

//            // Keep only last 10 messages (5 exchanges)
//            if (_conversationHistory.Count > 10)
//            {
//                _conversationHistory.RemoveRange(0, _conversationHistory.Count - 10);
//            }
//        }

//        private async Task<ChatResponse> HandleWebSearch(string input)
//        {
//            string url = input.Substring("Search:".Length).Trim();
//            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri validUrl))
//            {
//                return new ChatResponse { Content = "Please provide a valid URL." };
//            }

//            try
//            {
//                _logger.LogInformation($"Starting web scrape: {url}");
//                var scrapedContent = await _webScraperService.ScrapeWebPageAsync(url);

//                var prompt = new StringBuilder()
//                    .AppendLine($"Analyze this webpage content from {url}:")
//                    .AppendLine("1. Main topic/purpose")
//                    .AppendLine("2. Key information")
//                    .AppendLine("3. Important findings")
//                    .AppendLine("\nContent:")
//                    .AppendLine(scrapedContent)
//                    .ToString();

//                var response = await ProcessChatRequest(prompt);
//                return new ChatResponse
//                {
//                    Content = $"Analysis of {url}:\n\n{response.Content}"
//                };
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, $"Failed to scrape {url}");
//                return new ChatResponse
//                {
//                    Content = $"Error accessing webpage. Please verify:\n" +
//                             "1. The URL is correct and accessible\n" +
//                             "2. Your internet connection is stable"
//                };
//            }
//        }

//        private async Task<string> GenerateImage(string prompt)
//        {
//            try
//            {
//                var endpoint = $"{BaseUrl}{ImageModelId}";
//                var payload = new
//                {
//                    inputs = prompt,
//                    parameters = new
//                    {
//                        guidance_scale = 7.5,
//                        num_inference_steps = 50
//                    }
//                };

//                var content = new StringContent(
//                    JsonConvert.SerializeObject(payload),
//                    Encoding.UTF8,
//                    "application/json"
//                );

//                using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(5));
//                var response = await _httpClient.PostAsync(endpoint, content, cts.Token);

//                if (!response.IsSuccessStatusCode)
//                {
//                    _logger.LogError($"Image generation failed: {response.StatusCode}");
//                    return "ERROR: Image generation failed.";
//                }

//                var contentType = response.Content.Headers.ContentType?.MediaType;
//                if (contentType != "image/png" && contentType != "image/jpeg")
//                {
//                    return $"ERROR: Unexpected content type: {contentType}";
//                }

//                var imageBytes = await response.Content.ReadAsByteArrayAsync();
//                return $"IMAGE:{contentType}:{Convert.ToBase64String(imageBytes)}";
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, "Error in GenerateImage");
//                return $"ERROR: Failed to generate image.";
//            }
//        }

//        public async ValueTask DisposeAsync()
//        {
//            if (_webScraperService != null)
//            {
//                await _webScraperService.DisposeAsync();
//            }
//            _httpClient?.Dispose();
//        }
//    }
//    public class ChatResponse
//    {
//        public string Content { get; set; }
//        public FunctionCall FunctionCall { get; set; }
//        public string ImageData { get; set; }
//    }

//    public class FunctionCall
//    {
//        public string Name { get; set; }
//        public Dictionary<string, string> Arguments { get; set; }
//    }
//}

using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Threading;
using System.Windows;

namespace Sojourner_AI.AINetwork
{
    public class ChatCompletionService : IAIService, IAsyncDisposable
    {
        private readonly HttpClient _httpClient;
        private string _modelId;
        private readonly ILogger _logger;
        private readonly WebViewScraperService _webScraperService;
        private readonly List<object> _conversationHistory;
        private const string BaseUrl = "https://api-inference.huggingface.co/models/";
        private const string ImageModelId = "black-forest-labs/FLUX.1-dev";
        private const int MaxNewTokens = 1000;
        private ModelConfig _currentModel;

        private static readonly Dictionary<string, ModelConfig> ModelConfigs = new()
        {
            ["google/gemma-1.1-7b-it"] = new ModelConfig
            {
                MaxTokens = 8192,
                Instructions = "You are Gemma, a helpful and knowledgeable AI. Be direct and concise for simple questions, detailed only when necessary. Use emojis where appropriate to make responses engaging. Never be verbose with basic queries."
            },
            ["meta-llama/Meta-Llama-3-8B-Instruct"] = new ModelConfig
            {
                MaxTokens = 4096,
                Instructions = "You are Llama, focused on precise and helpful responses. Keep it simple for basic questions, elaborate only when the topic requires depth. Aim for clarity and accuracy."
            },
            ["microsoft/Phi-3-mini-4k-instruct"] = new ModelConfig
            {
                MaxTokens = 4096,
                Instructions = "You are Phi, optimized for clear and accurate communication. Be concise. Provide step-by-step explanations only for complex topics. Use simple language for basic queries."
            },
            ["Qwen/Qwen2.5-1.5B-Instruct"] = new ModelConfig
            {
                MaxTokens = 6144,
                Instructions = "You are Qwen, specializing in efficient and accurate responses. Be direct and to the point. Elaborate only when the question demands detailed explanation."
            }
        };

        private class ModelConfig
        {
            public int MaxTokens { get; set; }
            public string Instructions { get; set; }
        }

        public ChatCompletionService(string modelId, string apiKey, ILogger logger)
        {
            if (!ModelConfigs.ContainsKey(modelId))
            {
                throw new ArgumentException($"Model {modelId} not supported");
            }

            _modelId = modelId;
            _currentModel = ModelConfigs[modelId];
            _logger = logger;
            _conversationHistory = new List<object>();

            // Initialize WebView components
            var mainWindow = Application.Current.MainWindow;
            var webViewDisplay = mainWindow.FindName("WebViewDisplay") as System.Windows.Controls.Border;
            var webViewTitle = mainWindow.FindName("WebViewTitle") as System.Windows.Controls.TextBlock;
            var webViewContainer = mainWindow.FindName("WebViewContainer") as System.Windows.Controls.Border;
            var loadingGrid = mainWindow.FindName("LoadingGrid") as System.Windows.Controls.Grid;

            if (webViewDisplay == null || webViewTitle == null ||
                webViewContainer == null || loadingGrid == null)
            {
                throw new InvalidOperationException("Required WebView UI elements not found");
            }

            _webScraperService = new WebViewScraperService(
                logger: logger,
                webViewDisplay: webViewDisplay,
                webViewTitle: webViewTitle,
                webViewContainer: webViewContainer,
                loadingGrid: loadingGrid
            );

            _httpClient = new HttpClient { Timeout = TimeSpan.FromMinutes(5) };
            _httpClient.DefaultRequestHeaders.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", apiKey);
            _httpClient.DefaultRequestHeaders.Add("x-wait-for-model", "true");
        }

        public void UpdateModel(string modelId)
        {
            if (!ModelConfigs.ContainsKey(modelId))
            {
                throw new ArgumentException($"Model {modelId} not supported");
            }

            _modelId = modelId;
            _currentModel = ModelConfigs[modelId];
            _conversationHistory.Clear(); // Clear history when switching models
            _logger.LogInformation($"Switched to model: {modelId} with max tokens: {_currentModel.MaxTokens}");
        }

        public async Task<ChatResponse> ProcessRequest(string input)
        {
            try
            {
                if (input.StartsWith("Generate an image:", StringComparison.OrdinalIgnoreCase))
                {
                    string imagePrompt = input.Substring("Generate an image:".Length).Trim();
                    string imageData = await GenerateImage(imagePrompt);
                    return new ChatResponse
                    {
                        Content = $"Image generated based on prompt: {imagePrompt}",
                        ImageData = imageData
                    };
                }
                else if (input.StartsWith("Search:", StringComparison.OrdinalIgnoreCase))
                {
                    return await HandleWebSearch(input);
                }
                else
                {
                    var chatResponse = await ProcessChatRequest(input);
                    UpdateConversationHistory(input, chatResponse.Content);
                    return chatResponse;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing request");
                return new ChatResponse
                {
                    Content = "I encountered an error. Please try again or rephrase your question."
                };
            }
        }

        private async Task<ChatResponse> ProcessChatRequest(string input)
        {
            try
            {
                var endpoint = $"{BaseUrl}{_modelId}";
                var messages = BuildMessageHistory(input);

                // Calculate remaining tokens for response
                int usedTokens = messages.Sum(m => EstimateTokenCount(((dynamic)m).content.ToString()));
                int maxNewTokens = Math.Min(MaxNewTokens, _currentModel.MaxTokens - usedTokens);

                var payload = new
                {
                    messages = messages,
                    temperature = 0.5,
                    top_p = 0.9,
                    max_tokens = maxNewTokens,
                    stream = false,
                    frequency_penalty = 0.3,
                    presence_penalty = 0.3
                };

                var content = new StringContent(
                    JsonConvert.SerializeObject(payload),
                    Encoding.UTF8,
                    "application/json"
                );

                var response = await _httpClient.PostAsync(endpoint, content);
                var responseBody = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"API Error: {response.StatusCode}, {responseBody}");
                    return new ChatResponse
                    {
                        Content = "Sorry, I'm having trouble processing your request right now."
                    };
                }

                var jsonResponse = JObject.Parse(responseBody);
                var generatedText = jsonResponse["choices"]?[0]?["message"]?["content"]?.ToString().Trim();

                if (string.IsNullOrEmpty(generatedText))
                {
                    return new ChatResponse
                    {
                        Content = "I couldn't generate a proper response. Please try again."
                    };
                }

                return new ChatResponse { Content = generatedText };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in ProcessChatRequest");
                return new ChatResponse
                {
                    Content = "An error occurred while processing your request."
                };
            }
        }

        private List<object> BuildMessageHistory(string newInput)
        {
            var messages = new List<object>
            {
                new
                {
                    role = "system",
                    content = _currentModel.Instructions
                }
            };

            // Calculate available tokens
            int systemTokens = EstimateTokenCount(_currentModel.Instructions);
            int newInputTokens = EstimateTokenCount(newInput);
            int availableTokens = _currentModel.MaxTokens - systemTokens - newInputTokens - MaxNewTokens;

            // Add conversation history within token limit
            var recentMessages = new List<object>();
            int currentTokens = 0;

            foreach (var msg in _conversationHistory.AsEnumerable().Reverse())
            {
                var msgObj = (dynamic)msg;
                int msgTokens = EstimateTokenCount(msgObj.content.ToString());

                if (currentTokens + msgTokens > availableTokens)
                    break;

                recentMessages.Insert(0, msg);
                currentTokens += msgTokens;
            }

            messages.AddRange(recentMessages);
            messages.Add(new { role = "user", content = newInput });

            return messages;
        }

        private int EstimateTokenCount(string text)
        {
            // Rough estimation: ~4 chars per token for English text
            return (int)Math.Ceiling(text.Length / 4.0);
        }

        private void UpdateConversationHistory(string userInput, string assistantResponse)
        {
            _conversationHistory.Add(new { role = "user", content = userInput });
            _conversationHistory.Add(new { role = "assistant", content = assistantResponse });

            // Keep only last 10 messages (5 exchanges)
            if (_conversationHistory.Count > 10)
            {
                _conversationHistory.RemoveRange(0, _conversationHistory.Count - 10);
            }
        }

        private async Task<ChatResponse> HandleWebSearch(string input)
        {
            string url = input.Substring("Search:".Length).Trim();
            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri validUrl))
            {
                return new ChatResponse { Content = "Please provide a valid URL." };
            }

            try
            {
                _logger.LogInformation($"Starting web scrape: {url}");
                var scrapedContent = await _webScraperService.ScrapeWebPageAsync(url);

                var prompt = new StringBuilder()
                    .AppendLine($"Analyze this webpage content from {url}:")
                    .AppendLine("1. Main topic/purpose")
                    .AppendLine("2. Key information")
                    .AppendLine("3. Important findings")
                    .AppendLine("\nContent:")
                    .AppendLine(scrapedContent)
                    .ToString();

                var response = await ProcessChatRequest(prompt);
                return new ChatResponse
                {
                    Content = $"Analysis of {url}:\n\n{response.Content}"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to scrape {url}");
                return new ChatResponse
                {
                    Content = $"Error accessing webpage. Please verify:\n" +
                             "1. The URL is correct and accessible\n" +
                             "2. Your internet connection is stable"
                };
            }
        }

        private async Task<string> GenerateImage(string prompt)
        {
            try
            {
                var endpoint = $"{BaseUrl}{ImageModelId}";
                var payload = new
                {
                    inputs = prompt,
                    parameters = new
                    {
                        guidance_scale = 7.5,
                        num_inference_steps = 50
                    }
                };

                var content = new StringContent(
                    JsonConvert.SerializeObject(payload),
                    Encoding.UTF8,
                    "application/json"
                );

                using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(5));
                var response = await _httpClient.PostAsync(endpoint, content, cts.Token);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Image generation failed: {response.StatusCode}");
                    return "ERROR: Image generation failed.";
                }

                var contentType = response.Content.Headers.ContentType?.MediaType;
                if (contentType != "image/png" && contentType != "image/jpeg")
                {
                    return $"ERROR: Unexpected content type: {contentType}";
                }

                var imageBytes = await response.Content.ReadAsByteArrayAsync();
                return $"IMAGE:{contentType}:{Convert.ToBase64String(imageBytes)}";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GenerateImage");
                return $"ERROR: Failed to generate image.";
            }
        }

        public async ValueTask DisposeAsync()
        {
            if (_webScraperService != null)
            {
                await _webScraperService.DisposeAsync();
            }
            _httpClient?.Dispose();
        }
    }

    public class ChatResponse
    {
        public string Content { get; set; }
        public FunctionCall FunctionCall { get; set; }
        public string ImageData { get; set; }
    }

    public class FunctionCall
    {
        public string Name { get; set; }
        public Dictionary<string, string> Arguments { get; set; }
    }
}