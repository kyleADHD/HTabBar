﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ICSharpCode.AvalonEdit.Highlighting;
using Microsoft.Extensions.Logging;
using System.Windows.Threading;
using System.IO;
using System.Xml;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using System.Text;
using System.Windows.Media;
using System.Text.RegularExpressions;
using Sojourner_AI.Loggers;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using static System.Net.WebRequestMethods;
using System.Security.Policy;
using Sojourner_AI.AINetwork;
using Microsoft.Web.WebView2.Wpf;


namespace Sojourner_AI
{
     public partial class MainWindow : Window
    {
        private SojournerHub _sojournerHub;
        private SimpleConsoleLogger logger;
        private ObservableCollection<ChatMessage> messages;
        private List<Dictionary<string, string>> conversationHistory;
        private bool _isDarkMode = false;
        private IHighlightingDefinition customHighlighting;
        private const int MAX_HISTORY_MESSAGES = 3;
       // private const int MAX_TOKENS = 3500;
        private DispatcherTimer typingTimer;
        private DispatcherTimer animationTimer;
        private string fullResponse;
        private int currentIndex;
        private ObservableCollection<AIModel> aiModels;
        private AIModel selectedModel;
        private ChatMessage currentAIMessage;
        private WebViewScraperService _webViewScraperService;
        private ILogger<MainWindow> _logger;
        private const string ApiKey = "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";
        private const string ModelId = "microsoft/Phi-3-mini-4k-instruct";
        private const string CustomHighlightingDefinition = @"<?xml version=""1.0"" encoding=""utf-8""?>
<SyntaxDefinition name=""Custom"" xmlns=""http://icsharpcode.net/sharpdevelop/syntaxdefinition/2008"">
    <Color name=""Comment"" foreground=""#6A9955"" />
    <Color name=""String"" foreground=""#CE9178"" />
    <Color name=""Keyword"" foreground=""#C678DD"" />
    <Color name=""TypeKeyword"" foreground=""#4EC9B0"" />
    <Color name=""Punctuation"" foreground=""#C678DD"" />
    <Color name=""Number"" foreground=""#C678DD"" />
    <Color name=""MethodCall"" foreground=""#D19A66"" />
    <Color name=""Class"" foreground=""#C678DD"" />

    <RuleSet>
    <!-- Comments -->
    <Span color=""Comment"" begin=""//"" />
    <Span color=""Comment"" multiline=""true"" begin=""/\*"" end=""\*/"" />
    <Span color=""Comment"" begin=""#"" />
    <Span color=""Comment"" multiline=""true"" begin=""'''"" end=""'''"" />

    <!-- Strings -->
    <Span color=""String"">
        <Begin>""</Begin>
        <End>""</End>
        <RuleSet>
            <Span begin=""\\"" end=""."" />
        </RuleSet>
    </Span>
    <Span color=""String"">
        <Begin>'</Begin>
        <End>'</End>
        <RuleSet>
            <Span begin=""\\"" end=""."" />
        </RuleSet>
    </Span>
    <Span color=""String"" multiline=""true"">
        <Begin>@""</Begin>
        <End>""</End>
        <RuleSet>
            <Span begin='""""' end="""" />
        </RuleSet>
    </Span>

    <!-- Keywords for multiple languages -->
    <Keywords color=""Keyword"">
        <!-- C# keywords -->
        <Word>abstract</Word>
        <Word>as</Word>
        <Word>base</Word>
        <Word>bool</Word>
        <Word>break</Word>
        <Word>byte</Word>
        <Word>case</Word>
        <Word>catch</Word>
        <Word>char</Word>
        <Word>checked</Word>
        <Word>class</Word>
        <Word>const</Word>
        <Word>continue</Word>
        <Word>decimal</Word>
        <Word>default</Word>
        <Word>delegate</Word>
        <Word>do</Word>
        <Word>double</Word>
        <Word>else</Word>
        <Word>enum</Word>
        <Word>event</Word>
        <Word>explicit</Word>
        <Word>extern</Word>
        <Word>false</Word>
        <Word>finally</Word>
        <Word>fixed</Word>
        <Word>float</Word>
        <Word>for</Word>
        <Word>foreach</Word>
        <Word>goto</Word>
        <Word>if</Word>
        <Word>implicit</Word>
        <Word>in</Word>
        <Word>int</Word>
        <Word>interface</Word>
        <Word>internal</Word>
        <Word>is</Word>
        <Word>lock</Word>
        <Word>long</Word>
        <Word>namespace</Word>
        <Word>new</Word>
        <Word>null</Word>
        <Word>object</Word>
        <Word>operator</Word>
        <Word>out</Word>
        <Word>override</Word>
        <Word>params</Word>
        <Word>private</Word>
        <Word>protected</Word>
        <Word>public</Word>
        <Word>readonly</Word>
        <Word>ref</Word>
        <Word>return</Word>
        <Word>sbyte</Word>
        <Word>sealed</Word>
        <Word>short</Word>
        <Word>sizeof</Word>
        <Word>stackalloc</Word>
        <Word>static</Word>
        <Word>string</Word>
        <Word>struct</Word>
        <Word>switch</Word>
        <Word>this</Word>
        <Word>throw</Word>
        <Word>true</Word>
        <Word>try</Word>
        <Word>typeof</Word>
        <Word>uint</Word>
        <Word>ulong</Word>
        <Word>unchecked</Word>
        <Word>unsafe</Word>
        <Word>ushort</Word>
        <Word>using</Word>
        <Word>virtual</Word>
        <Word>void</Word>
        <Word>volatile</Word>
        <Word>while</Word>

        <!-- Python keywords -->
        <Word>and</Word>
        <Word>as</Word>
        <Word>assert</Word>
        <Word>async</Word>
        <Word>await</Word>
        <Word>break</Word>
        <Word>class</Word>
        <Word>continue</Word>
        <Word>def</Word>
        <Word>del</Word>
        <Word>elif</Word>
        <Word>else</Word>
        <Word>except</Word>
        <Word>finally</Word>
        <Word>for</Word>
        <Word>from</Word>
        <Word>global</Word>
        <Word>if</Word>
        <Word>import</Word>
        <Word>in</Word>
        <Word>is</Word>
        <Word>lambda</Word>
        <Word>nonlocal</Word>
        <Word>not</Word>
        <Word>or</Word>
        <Word>pass</Word>
        <Word>raise</Word>
        <Word>return</Word>
        <Word>try</Word>
        <Word>while</Word>
        <Word>with</Word>
        <Word>yield</Word>

        <!-- JavaScript keywords -->
        <Word>var</Word>
        <Word>let</Word>
        <Word>const</Word>
        <Word>function</Word>
        <Word>async</Word>
        <Word>await</Word>
        <Word>class</Word>
        <Word>extends</Word>
        <Word>super</Word>
        <Word>import</Word>
        <Word>export</Word>
        <Word>from</Word>
        <Word>typeof</Word>
        <Word>instanceof</Word>
    </Keywords>

    <!-- Type keywords -->
    <Keywords color=""TypeKeyword"">
        <Word>class</Word>
        <Word>interface</Word>
        <Word>enum</Word>
        <Word>struct</Word>
        <Word>def</Word>
    </Keywords>

    <!-- Method calls -->
    <Rule color=""MethodCall"">
        \b
        [\w]+  # an identifier
        (?=\s*\() # followed by (
    </Rule>

    <!-- Class names -->
    <Rule color=""Class"">
        \b[A-Z][\w]*\b
    </Rule>

    <!-- Punctuation -->
    <Rule color=""Punctuation"">
        [!&amp;()*+,-./:;&lt;=&gt;?\[\]^{|}~]+
    </Rule>

    <!-- Numbers -->
    <Rule color=""Number"">
        \b0[xX][0-9a-fA-F]+|(\b\d+(\.[0-9]+)?|\.[0-9]+)([eE][+-]?[0-9]+)?
    </Rule>
</RuleSet>
</SyntaxDefinition>";
        public MainWindow()
        {
            InitializeComponent();
            _webViewScraperService = new WebViewScraperService(
      logger: _logger,
      webViewDisplay: WebViewDisplay,
      webViewTitle: WebViewTitle,
      webViewContainer: WebViewContainer,
      loadingGrid: LoadingGrid
  );
            InitializeComponents();
            Closing += MainWindow_Closing;

        }
        private void InitializeAIModels()
        {
            aiModels = new ObservableCollection<AIModel>
            {
                new AIModel("nvidia/Llama-3.1-Nemotron-70B-Instruct-HF", "Nemotron-70B-Instruct-HF", "Llama-3.1-Nemotron-70B-Instruct is a large language model customized by NVIDIA to improve the helpfulness of LLM generated responses to user queries."),
                new AIModel("google/gemma-1.1-7b-it", "Gemma-1.1", "Gemma is a family of lightweight, state-of-the-art open models from Google"),
                new AIModel("meta-llama/Meta-Llama-3-8B-Instruct", "Llama-3", "The Meta Llama 3.1 are optimized for multilingual dialogue use cases and outperform many of the available open source"),
                new AIModel("meta-llama/Llama-3.2-11B-Vision-Instruct", "Llama-3.2 Vision", "The Meta Llama 3.1 are optimized for multilingual dialogue use cases and outperform many of the available open source"),
                new AIModel("microsoft/Phi-3-mini-4k-instruct", "Phi-3 Mini", "Phi-3-Mini-4K-Instruct is a lightweight, state-of-the-art open model trained with the Phi-3 datasets"),
                new AIModel("Qwen/Qwen2.5-1.5B-Instruct", "Qwen2.5", "Qwen2.5 brings the following improvements upon Qwen2:\r\n\r\nSignificantly more knowledge and has greatly improved capabilities in coding and mathematics.")

            };

            selectedModel = aiModels[0]; 
        }
        private void CloseWebView_Click(object sender, RoutedEventArgs e)
        {
            WebViewDisplay.Visibility = Visibility.Collapsed;
        }
        private void InitializeComponents()
        {
            _logger = new Logger<MainWindow>(new LoggerFactory());
            _sojournerHub = new SojournerHub();
            InitializeAIModels();
            ModelSelector.ItemsSource = aiModels;
            ModelSelector.SelectedIndex = 0;
            _sojournerHub.RegisterService("ChatCompletion", new ChatCompletionService(selectedModel.ModelId, ApiKey, _logger));

            ModelSelector.SelectionChanged += ModelSelector_SelectionChanged;
            logger = new SimpleConsoleLogger();
            messages = new ObservableCollection<ChatMessage>();
            ChatMessages.ItemsSource = messages;
            conversationHistory = new List<Dictionary<string, string>>();

            MessageInput.KeyDown += MessageInput_KeyDown;
            LeftColumn.Width = new GridLength(1, GridUnitType.Star);
            ChatColumn.Width = new GridLength(2, GridUnitType.Star);
            CodeColumn.Width = new GridLength(0);
            LoadCustomHighlighting();
            animationTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
            animationTimer.Tick += AnimationTimer_Tick;
        }
        private async void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                var chatService = _sojournerHub.GetService("ChatCompletion") as ChatCompletionService;
                if (chatService != null)
                {
                    await chatService.DisposeAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error disposing services");
            }
        }
        private void ModelSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedModel = (AIModel)ModelSelector.SelectedItem;
            UpdateModelDescription();
            ResetChatService();
        }
        private void UpdateModelDescription()
        {
           //// ModelDescription.Text = selectedModel.Description;
        }

        private void ResetChatService()
        {
            _sojournerHub.RegisterService("ChatCompletion",
                new ChatCompletionService(selectedModel.ModelId, ApiKey, _logger));
        }
        private void LoadCustomHighlighting()
        {
            try
            {
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(CustomHighlightingDefinition)))
                using (var reader = new XmlTextReader(stream))
                {
                    customHighlighting = HighlightingLoader.Load(reader, HighlightingManager.Instance);
                }
                Console.WriteLine("Custom highlighting loaded successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading custom highlighting: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                MessageBox.Show($"Error loading custom highlighting: {ex.Message}");
            }
        }

        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            LoaderRotate.Angle = (LoaderRotate.Angle + 10) % 360;
        }

       
        private void StartSpinner(bool isWebScraping = false)
        {
            Dispatcher.Invoke(() =>
            {
                if (isWebScraping)
                {
                    WebScrapingIndicator.Visibility = Visibility.Visible;
                    LoadingIndicator.Visibility = Visibility.Collapsed;
                }
                else
                {
                    LoadingIndicator.Visibility = Visibility.Visible;
                    WebScrapingIndicator.Visibility = Visibility.Collapsed;
                }
                animationTimer.Start();
            });
        }

        private void StopSpinner()
        {
            Dispatcher.Invoke(() =>
            {
                animationTimer.Stop();
                LoadingIndicator.Visibility = Visibility.Collapsed;
                WebScrapingIndicator.Visibility = Visibility.Collapsed;
            });
        }
      

        private void DarkModeToggle_Click(object sender, RoutedEventArgs e)
        {
            _isDarkMode = !_isDarkMode;
            UpdateTheme();
        }

        private void UpdateTheme()
        {
            var theme = _isDarkMode ? "Dark" : "Light";
            Resources["BackgroundBrush"] = (SolidColorBrush)Resources[$"{theme}BackgroundBrush"];
            Resources["BorderBrush"] = (SolidColorBrush)Resources[$"{theme}BorderBrush"];
            Resources["PrimaryTextBrush"] = (SolidColorBrush)Resources[$"{theme}PrimaryTextBrush"];
            Resources["SecondaryTextBrush"] = (SolidColorBrush)Resources[$"{theme}SecondaryTextBrush"];
            Resources["InputBackgroundBrush"] = (SolidColorBrush)Resources[$"{theme}InputBackgroundBrush"];
            Resources["UserMessageBrush"] = (SolidColorBrush)Resources[$"{theme}UserMessageBrush"];
            Resources["AIMessageBrush"] = (SolidColorBrush)Resources[$"{theme}AIMessageBrush"];
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            await SendMessage();
        }

        private async void MessageInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                await SendMessage();
            }
        }

        private async Task SendMessage()
        {
            string userMessage = MessageInput.Text.Trim();
            if (string.IsNullOrEmpty(userMessage))
            {
                MessageBox.Show("Please enter a message.", "Empty Message", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            await Dispatcher.InvokeAsync(() =>
            {
                messages.Add(new ChatMessage { IsUser = true, Sender = "You", Content = new List<object> { new TextContent { Text = userMessage } }, IsLoading = false });
                MessageInput.Clear();
            });

            ShowSpinner(userMessage.StartsWith("Search:", StringComparison.OrdinalIgnoreCase));
            try
            {
                var chatService = _sojournerHub.GetService("ChatCompletion") as ChatCompletionService;
                var chatResponse = await chatService.ProcessRequest(userMessage);

                HideSpinner();

                await Dispatcher.InvokeAsync(() =>
                {
                    currentAIMessage = new ChatMessage
                    {
                        IsUser = false,
                        Sender = "SojournerAI",
                        Content = new List<object>(),
                        IsLoading = false
                    };

                    if (!string.IsNullOrEmpty(chatResponse.Content))
                    {
                        var content = userMessage.StartsWith("Search:", StringComparison.OrdinalIgnoreCase) ?
                            ProcessWebContent(chatResponse.Content) :
                            chatResponse.Content;

                        currentAIMessage.Content.Add(new TextContent { Text = content });
                    }

                    if (!string.IsNullOrEmpty(chatResponse.ImageData))
                    {
                        var image = ConvertBase64ToImage(chatResponse.ImageData);
                        if (image != null)
                        {
                            currentAIMessage.Content.Add(new ImageContent
                            {
                                Image = image,
                                Title = "View Generated Image"
                            });
                        }
                    }

                    messages.Add(currentAIMessage);
                    ScrollToBottom();
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in SendMessage");
                HideSpinner();
                await Dispatcher.InvokeAsync(() =>
                {
                    messages.Add(new ChatMessage
                    {
                        IsUser = false,
                        Sender = "SojournerAI",
                        Content = new List<object> {
                    new TextContent { Text = $"Error: An unexpected error occurred. Please try again later." }
                },
                        IsLoading = false
                    });
                });
            }
        }
        private string ProcessWebContent(string content)
        {
            try
            {
                // Format the web content for better readability
                var formattedContent = content
                    .Replace("\n", "\n\n")  // Add extra line breaks for readability
                    .Replace("Content from ", "📄 Content from ")  // Add emoji for web content
                    .Replace("Summary:", "📝 Summary:")
                    .Replace("Key information:", "🔑 Key information:")
                    .Replace("Important findings:", "📎 Important findings:")
                    .Replace("Analysis of ", "🔍 Analysis of ");

                // Add section breaks for better visual separation
                formattedContent = Regex.Replace(formattedContent,
                    @"(\d+\. )",
                    "\n$1",  // Add newline before numbered points
                    RegexOptions.Multiline);

                // Clean up any excessive whitespace
                formattedContent = Regex.Replace(formattedContent, @"\n\s*\n\s*\n", "\n\n");

                return formattedContent;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing web content");
                return content; // Return original content if processing fails
            }
        }

        private void ScrollToBottom()
        {
            try
            {
                if (ChatMessages.ItemsSource != null)
                {
                    var scrollViewer = GetScrollViewer(ChatMessages);
                    scrollViewer?.ScrollToEnd();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error scrolling to bottom");
            }
        }

        private ScrollViewer GetScrollViewer(DependencyObject element)
        {
            if (element is ScrollViewer scrollViewer)
            {
                return scrollViewer;
            }

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(element); i++)
            {
                var child = VisualTreeHelper.GetChild(element, i);
                var result = GetScrollViewer(child);
                if (result != null)
                {
                    return result;
                }
            }

            return null;
        }

        // Add this if you don't have it already
        private void UpdateLayout()
        {
            try
            {
                var scrollViewer = GetScrollViewer(ChatMessages);
                if (scrollViewer != null)
                {
                    // Force layout update
                    scrollViewer.UpdateLayout();

                    // Add a small delay before scrolling to ensure content is rendered
                    Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
                    {
                        scrollViewer.ScrollToEnd();
                    }));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating layout");
            }
        }
        private void ShowSpinner(bool isWebScraping)
        {
            Dispatcher.Invoke(() =>
            {
                if (isWebScraping)
                {
                    WebScrapingIndicator.Visibility = Visibility.Visible;
                    LoadingIndicator.Visibility = Visibility.Collapsed;
                }
                else
                {
                    LoadingIndicator.Visibility = Visibility.Visible;
                    WebScrapingIndicator.Visibility = Visibility.Collapsed;
                }
                animationTimer.Start();
            });
        }

        private void HideSpinner()
        {
            Dispatcher.Invoke(() =>
            {
                animationTimer.Stop();
                LoadingIndicator.Visibility = Visibility.Collapsed;
                WebScrapingIndicator.Visibility = Visibility.Collapsed;
            });
        }
        private BitmapImage ConvertBase64ToImage(string base64String)
        {
            try
            {
                string[] parts = base64String.Split(':');
                if (parts.Length != 3 || !parts[0].Equals("IMAGE", StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogError($"Invalid image data format: {base64String}");
                    return null;
                }

                string contentType = parts[1];
                string imageData = parts[2];

                byte[] imageBytes = Convert.FromBase64String(imageData);
                using (var ms = new System.IO.MemoryStream(imageBytes))
                {
                    var image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.StreamSource = ms;
                    image.EndInit();
                    return image;
                }
            }
            catch (FormatException ex)
            {
                _logger.LogError(ex, "Error converting Base64 to image. Base64 string: " + base64String);
                return null;
            }
        }
        private void ViewImage_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var imageContent = (ImageContent)button.Tag;
            DisplayImageInCodeWindow(imageContent.Image);
        }

        private void DisplayImageInCodeWindow(BitmapImage image)
        {
            GeneratedImage.Source = image;
            CodeBlockDisplay.Visibility = Visibility.Collapsed;
            ImageDisplay.Visibility = Visibility.Visible;
            LeftColumn.Width = new GridLength(0);
            ChatColumn.Width = new GridLength(1, GridUnitType.Star);
            CodeColumn.Width = new GridLength(1, GridUnitType.Star);
        }

        private void CloseImage_Click(object sender, RoutedEventArgs e)
        {
            HideImageDisplay();
        }

        private void HideImageDisplay()
        {
            ImageDisplay.Visibility = Visibility.Collapsed;
            LeftColumn.Width = new GridLength(1, GridUnitType.Star);
            ChatColumn.Width = new GridLength(2, GridUnitType.Star);
            CodeColumn.Width = new GridLength(0);
        }
        private bool IsImageGenerationRequest(string message)
        {
            return message.StartsWith("Generate an image:", StringComparison.OrdinalIgnoreCase) ||
                   (message.Length > 100 &&
                    (message.Contains("image") || message.Contains("picture") || message.Contains("photo") ||
                     message.Contains("draw") || message.Contains("create") || message.Contains("generate")));
        }

        private void DisplayGeneratedImage(string base64Image)
        {
            var imageBytes = Convert.FromBase64String(base64Image);
            var image = new BitmapImage();
            using (var ms = new MemoryStream(imageBytes))
            {
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = ms;
                image.EndInit();
            }

            Dispatcher.Invoke(() =>
            {
                currentAIMessage.Content.Add(new ImageContent { Image = image });
                currentAIMessage.Content = new List<object>(currentAIMessage.Content);
            });
        }
        private void StartTypingEffect()
        {
            currentIndex = 0;
            typingTimer = new DispatcherTimer();
            typingTimer.Interval = TimeSpan.FromMilliseconds(8);
            typingTimer.Tick += TypingTimer_Tick;
            typingTimer.Start();
        }

        private void TypingTimer_Tick(object sender, EventArgs e)
        {
            const int charactersPerTick = 5;

            for (int i = 0; i < charactersPerTick && currentIndex < fullResponse.Length; i++)
            {
                char currentChar = fullResponse[currentIndex];
                if (currentChar == '`' && currentIndex + 2 < fullResponse.Length && fullResponse[currentIndex + 1] == '`' && fullResponse[currentIndex + 2] == '`')
                {
                    int endIndex = fullResponse.IndexOf("```", currentIndex + 3);
                    if (endIndex != -1)
                    {
                        string codeBlock = fullResponse.Substring(currentIndex, endIndex - currentIndex + 3);
                        var parsedCodeBlock = ParseMessageWithCodeBlocks(codeBlock);
                        Dispatcher.Invoke(() =>
                        {
                            currentAIMessage.Content.AddRange(parsedCodeBlock);
                            currentAIMessage.Content = new List<object>(currentAIMessage.Content);
                        });
                        currentIndex = endIndex + 3;
                        break;
                    }
                }
                else
                {
                    Dispatcher.Invoke(() =>
                    {
                        if (currentAIMessage.Content.Count == 0 || !(currentAIMessage.Content[currentAIMessage.Content.Count - 1] is TextContent))
                        {
                            currentAIMessage.Content.Add(new TextContent { Text = "" });
                        }
                        ((TextContent)currentAIMessage.Content[currentAIMessage.Content.Count - 1]).Text += currentChar;
                    });
                    currentIndex++;
                }
            }

            Dispatcher.Invoke(() =>
            {
                currentAIMessage.Content = new List<object>(currentAIMessage.Content);
            });

            if (currentIndex >= fullResponse.Length)
            {
                typingTimer.Stop();
            }
        }

        private List<object> ParseMessageWithCodeBlocks(string message)
        {
            var parts = new List<object>();
            var regex = new Regex(@"```([\s\S]*?)```|`([^`\n]+)`");
            int lastIndex = 0;
            int codeBlockCount = 0;

            foreach (Match match in regex.Matches(message))
            {
                if (match.Index > lastIndex)
                {
                    parts.Add(new TextContent { Text = message.Substring(lastIndex, match.Index - lastIndex) });
                }

                string codeContent = match.Groups[1].Success ? match.Groups[1].Value : match.Groups[2].Value;
                string language = "plaintext";
                string title = $"Code Snippet {++codeBlockCount}";

                // Check if the code block has a language specified
                var languageMatch = Regex.Match(codeContent, @"^([\w#]+)[\s\n]");
                if (languageMatch.Success)
                {
                    language = languageMatch.Groups[1].Value.Trim();
                    codeContent = codeContent.Substring(languageMatch.Length).Trim();
                }

                // Try to extract a title from the first line of the code
                var titleMatch = Regex.Match(codeContent, @"^.*?(\w[\w\s]+).*?$", RegexOptions.Multiline);
                if (titleMatch.Success)
                {
                    title = titleMatch.Groups[1].Value.Trim();
                }

                parts.Add(new CodeBlock
                {
                    Title = title,
                    Language = language,
                    Code = codeContent.Trim()
                });

                lastIndex = match.Index + match.Length;
            }

            if (lastIndex < message.Length)
            {
                parts.Add(new TextContent { Text = message.Substring(lastIndex) });
            }

            return parts;
        }
        private void ViewCodeBlock_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var codeBlock = (CodeBlock)button.Tag;
            DisplayCodeBlock(codeBlock);
        }

        private void DisplayCodeBlock(CodeBlock codeBlock)
        {
            CodeEditor.Text = codeBlock.Code;
            CodeEditor.SyntaxHighlighting = customHighlighting;
            CodeBlockTitle.Content = codeBlock.Title;
            LeftColumn.Width = new GridLength(0);
            ChatColumn.Width = new GridLength(1, GridUnitType.Star);
            CodeColumn.Width = new GridLength(1, GridUnitType.Star);
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            StartingStack.Visibility = Visibility.Collapsed;
            await SendMessage();
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Clipboard.SetText(CodeEditor.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to copy code: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseCodeBlock_Click(object sender, RoutedEventArgs e)
        {
            HideCodeBlock();
        }

        private void HideCodeBlock()
        {
            LeftColumn.Width = new GridLength(1, GridUnitType.Star);
            ChatColumn.Width = new GridLength(2, GridUnitType.Star);
            CodeColumn.Width = new GridLength(0);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageInput.Text = "Help me write a short poem about life";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageInput.Text = "Make me a plan to buy a new car";
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            MessageInput.Text = "Help me summarize this text :";
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            MessageInput.Text = "Please help me Debug this code :";
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            MessageInput.Text = "Please help me analyze this data : ";
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            MessageInput.Text = "Generate an Image: Create me a Pixar styled cool swauve character";
        }

        private void NewChat_Click(object sender, RoutedEventArgs e)
        {
            StartingStack.Visibility = Visibility.Visible;
            messages.Clear(); // Clear messages
            var chatService = _sojournerHub.GetService("ChatCompletion") as ChatCompletionService;
            chatService?.UpdateModel(selectedModel.ModelId); // Reset the model state
            InitializeComponents();
        }
    }
}