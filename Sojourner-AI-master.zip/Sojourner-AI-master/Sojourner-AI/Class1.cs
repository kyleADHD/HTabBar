﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sojourner_AI
{
    internal class Class1
    {
        //using System;
        //using System.Collections.Generic;
        //using System.Collections.ObjectModel;
        //using System.ComponentModel;
        //using System.Globalization;
        //using System.IO;
        //using System.Net.Http;
        //using System.Text;
        //using System.Text.RegularExpressions;
        //using System.Threading.Tasks;
        //using System.Windows;
        //using System.Windows.Controls;
        //using System.Windows.Data;
        //using System.Windows.Input;
        //using System.Windows.Media;
        //using ICSharpCode.AvalonEdit.Highlighting;
        //using ICSharpCode.AvalonEdit.Highlighting.Xshd;
        //using Microsoft.Extensions.Logging;
        //using Newtonsoft.Json;
        //using Newtonsoft.Json.Linq;
        //using System.Xml;
        //using System.IO;
        //using System.Text;
        //using System.Windows.Threading;
        //using System.Windows.Media.Animation;

        //namespace Sojourner_AI
        //{ 
        //    public partial class MainWindow : Window
        //    {
        //        private readonly HttpClient _httpClient = new HttpClient();
        //        private const string BaseUrl = "https://api-inference.huggingface.co/models/";
        //        private const string ApiKey = "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";
        //        private SimpleConsoleLogger logger;
        //        private ObservableCollection<ChatMessage> messages;
        //        private List<Dictionary<string, string>> conversationHistory;
        //        private bool _isDarkMode = false;
        //        private IHighlightingDefinition customHighlighting;
        //        private const int MAX_HISTORY_MESSAGES = 3;
        //        private const int MAX_TOKENS = 3500;
        //        private DispatcherTimer typingTimer;
        //        private DispatcherTimer animationTimer; 
        //        private string fullResponse;
        //        private int currentIndex;
        //        private ChatMessage currentAIMessage;



        //        public MainWindow()
        //        {
        //            InitializeComponent();
        //            logger = new SimpleConsoleLogger();
        //            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", ApiKey);

        //            messages = new ObservableCollection<ChatMessage>();
        //            ChatMessages.ItemsSource = messages;

        //            conversationHistory = new List<Dictionary<string, string>>();

        //            MessageInput.KeyDown += MessageInput_KeyDown;
        //            LeftColumn.Width = new GridLength(1, GridUnitType.Star);
        //            ChatColumn.Width = new GridLength(2, GridUnitType.Star);
        //            CodeColumn.Width = new GridLength(0);
        //            LoadCustomHighlighting();
        //            animationTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
        //            animationTimer.Tick += AnimationTimer_Tick;

        //        }
        //        private void AnimationTimer_Tick(object sender, EventArgs e)
        //        {
        //            LoaderRotate.Angle = (LoaderRotate.Angle + 10) % 360;
        //        }

        //        private void StartSpinner()
        //        {
        //            Dispatcher.Invoke(() =>
        //            {
        //                LoadingIndicator.Visibility = Visibility.Visible;
        //                animationTimer.Start();
        //            });
        //        }

        //        private void StopSpinner()
        //        {
        //            Dispatcher.Invoke(() =>
        //            {
        //                animationTimer.Stop();
        //                LoadingIndicator.Visibility = Visibility.Collapsed;
        //            });
        //        }
        //        private void LoadCustomHighlighting()
        //        {
        //            try
        //            {
        //                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(CustomHighlightingDefinition)))
        //                using (var reader = new XmlTextReader(stream))
        //                {
        //                    customHighlighting = ICSharpCode.AvalonEdit.Highlighting.Xshd.HighlightingLoader.Load(reader, ICSharpCode.AvalonEdit.Highlighting.HighlightingManager.Instance);
        //                }
        //                Console.WriteLine("Custom highlighting loaded successfully.");
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine($"Error loading custom highlighting: {ex.Message}");
        //                Console.WriteLine($"Stack trace: {ex.StackTrace}");
        //                MessageBox.Show($"Error loading custom highlighting: {ex.Message}");
        //            }
        //        }
        //        private void DarkModeToggle_Click(object sender, RoutedEventArgs e)
        //        {
        //            _isDarkMode = !_isDarkMode;
        //            UpdateTheme();
        //        }

        //        private void UpdateTheme()
        //        {
        //            var theme = _isDarkMode ? "Dark" : "Light";
        //            Resources["BackgroundBrush"] = (SolidColorBrush)Resources[$"{theme}BackgroundBrush"];
        //            Resources["BorderBrush"] = (SolidColorBrush)Resources[$"{theme}BorderBrush"];
        //            Resources["PrimaryTextBrush"] = (SolidColorBrush)Resources[$"{theme}PrimaryTextBrush"];
        //            Resources["SecondaryTextBrush"] = (SolidColorBrush)Resources[$"{theme}SecondaryTextBrush"];
        //            Resources["InputBackgroundBrush"] = (SolidColorBrush)Resources[$"{theme}InputBackgroundBrush"];
        //            Resources["UserMessageBrush"] = (SolidColorBrush)Resources[$"{theme}UserMessageBrush"];
        //            Resources["AIMessageBrush"] = (SolidColorBrush)Resources[$"{theme}AIMessageBrush"];
        //        }

        //        private async void Button_Click(object sender, RoutedEventArgs e)
        //        {
        //            await SendMessage();
        //        }

        //        private async void MessageInput_KeyDown(object sender, KeyEventArgs e)
        //        {
        //            if (e.Key == Key.Enter)
        //            {
        //                await SendMessage();
        //            }
        //        }

        //        private async Task<string> PerformChatCompletion(bool useCache = true)
        //        {
        //            try
        //            {
        //                var modelId = "microsoft/Phi-3-mini-4k-instruct";
        //                var endpoint = $"{BaseUrl}{modelId}";

        //                var queryParams = new List<string> { "wait_for_model=true" };
        //                if (!useCache) queryParams.Add("use_cache=false");

        //                endpoint += $"?{string.Join("&", queryParams)}";

        //                var recentHistory = conversationHistory
        //                    .Skip(Math.Max(0, conversationHistory.Count - MAX_HISTORY_MESSAGES))
        //                    .ToList();

        //                var conversationString = string.Join("\n", recentHistory.Select(msg => $"{msg["role"]}: {msg["content"]}"));
        //                conversationString += "\nAI:";

        //                var payload = new
        //                {
        //                    inputs = conversationString,
        //                    parameters = new
        //                    {
        //                        max_new_tokens = 2000,
        //                        temperature = 0.7,
        //                        return_full_text = false
        //                    }
        //                };

        //                var content = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");

        //                var response = await _httpClient.PostAsync(endpoint, content);
        //                var responseBody = await response.Content.ReadAsStringAsync();

        //                logger.LogInformation("Full API Response: {Response}", responseBody);

        //                if (!response.IsSuccessStatusCode)
        //                {
        //                    return $"Error: API request failed with status code {response.StatusCode}. Response: {responseBody}";
        //                }

        //                var jsonResponse = JArray.Parse(responseBody);
        //                var generatedText = jsonResponse[0]?["generated_text"]?.ToString();

        //                if (string.IsNullOrEmpty(generatedText))
        //                {
        //                    logger.LogWarning("No recognizable content found in the API response");
        //                    return "The SojournerAI did not generate a response in the expected format. Here's what was returned:\n\n" + responseBody;
        //                }

        //                return generatedText.Trim();
        //            }
        //            catch (Exception ex)
        //            {
        //                logger.LogError(ex, "Error during chat completion");
        //                return $"Error: {ex.Message}";
        //            }
        //        }
        //        private async Task SendMessage()
        //        {
        //            string userMessage = MessageInput.Text.Trim();
        //            if (string.IsNullOrEmpty(userMessage))
        //            {
        //                MessageBox.Show("Please enter a message.", "Empty Message", MessageBoxButton.OK, MessageBoxImage.Warning);
        //                return;
        //            }

        //            if (userMessage.Length > 500)
        //            {
        //                MessageBox.Show("Your message is too long. Please limit it to 500 characters.", "Message Too Long", MessageBoxButton.OK, MessageBoxImage.Warning);
        //                return;
        //            }

        //            int estimatedTokens = TokenCounter.EstimateTokenCount(userMessage);
        //            if (estimatedTokens > 3500)
        //            {
        //                MessageBox.Show("Your message is too long. Please shorten it to fit within the model's context.", "Message Too Long", MessageBoxButton.OK, MessageBoxImage.Warning);
        //                return;
        //            }

        //            await Dispatcher.InvokeAsync(() =>
        //            {
        //                messages.Add(new ChatMessage { IsUser = true, Sender = "You", Content = new List<object> { new TextContent { Text = userMessage } }, IsLoading = false });
        //                MessageInput.Clear();
        //            });

        //            conversationHistory.Add(new Dictionary<string, string> { { "role", "Human" }, { "content", userMessage } });

        //            StartSpinner();

        //            try
        //            {
        //                string aiResponse = await PerformChatCompletion();
        //                Console.WriteLine($"AI Response received: {aiResponse}");

        //                StopSpinner();

        //                await Dispatcher.InvokeAsync(() =>
        //                {
        //                    currentAIMessage = new ChatMessage
        //                    {
        //                        IsUser = false,
        //                        Sender = "SojournerAI",
        //                        Content = new List<object>(),
        //                        IsLoading = false
        //                    };
        //                    messages.Add(currentAIMessage);
        //                    Console.WriteLine($"AI message added to messages collection. Count: {messages.Count}");
        //                });

        //                fullResponse = aiResponse;
        //                Console.WriteLine($"Starting typing effect. Full response length: {fullResponse.Length}");
        //                StartTypingEffect();

        //                conversationHistory.Add(new Dictionary<string, string> { { "role", "SojournerAI" }, { "content", aiResponse } });
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine($"Error in SendMessage: {ex.Message}");
        //                logger.LogError(ex, "Error during chat completion");
        //                StopSpinner();
        //                await Dispatcher.InvokeAsync(() =>
        //                {
        //                    messages.Add(new ChatMessage { IsUser = false, Sender = "SojournerAI", Content = new List<object> { new TextContent { Text = $"Error: An unexpected error occurred. Please try again later." } }, IsLoading = false });
        //                });
        //            }
        //        }
        //        private void StartTypingEffect()
        //        {
        //            currentIndex = 0;
        //            typingTimer = new DispatcherTimer();
        //            typingTimer.Interval = TimeSpan.FromMilliseconds(12); 
        //            typingTimer.Tick += TypingTimer_Tick;
        //            typingTimer.Start();
        //        }
        //        private void TypingTimer_Tick(object sender, EventArgs e)
        //        {
        //            const int charactersPerTick = 5; // Increase this value to type faster

        //            for (int i = 0; i < charactersPerTick && currentIndex < fullResponse.Length; i++)
        //            {
        //                char currentChar = fullResponse[currentIndex];
        //                if (currentChar == '`' && currentIndex + 2 < fullResponse.Length && fullResponse[currentIndex + 1] == '`' && fullResponse[currentIndex + 2] == '`')
        //                {
        //                    // Found start or end of code block
        //                    int endIndex = fullResponse.IndexOf("```", currentIndex + 3);
        //                    if (endIndex != -1)
        //                    {
        //                        string codeBlock = fullResponse.Substring(currentIndex, endIndex - currentIndex + 3);
        //                        var parsedCodeBlock = ParseMessageWithCodeBlocks(codeBlock);
        //                        Dispatcher.Invoke(() =>
        //                        {
        //                            currentAIMessage.Content.AddRange(parsedCodeBlock);
        //                            currentAIMessage.Content = new List<object>(currentAIMessage.Content); // Trigger property change
        //                        });
        //                        currentIndex = endIndex + 3;
        //                        break; // Exit the loop after processing a code block
        //                    }
        //                }
        //                else
        //                {
        //                    Dispatcher.Invoke(() =>
        //                    {
        //                        if (currentAIMessage.Content.Count == 0 || !(currentAIMessage.Content[currentAIMessage.Content.Count - 1] is TextContent))
        //                        {
        //                            currentAIMessage.Content.Add(new TextContent { Text = "" });
        //                        }
        //                        ((TextContent)currentAIMessage.Content[currentAIMessage.Content.Count - 1]).Text += currentChar;
        //                    });
        //                    currentIndex++;
        //                }
        //            }

        //            // Trigger UI update outside the loop
        //            Dispatcher.Invoke(() =>
        //            {
        //                currentAIMessage.Content = new List<object>(currentAIMessage.Content); // Trigger property change
        //            });

        //            if (currentIndex >= fullResponse.Length)
        //            {
        //                typingTimer.Stop();
        //            }
        //        }
        //        private List<object> ParseMessageWithCodeBlocks(string message)
        //        {
        //            var parts = new List<object>();
        //            var regex = new Regex(@"```(\w+)\n([\s\S]*?)```");
        //            int lastIndex = 0;

        //            foreach (Match match in regex.Matches(message))
        //            {
        //                if (match.Index > lastIndex)
        //                {
        //                    parts.Add(new TextContent { Text = message.Substring(lastIndex, match.Index - lastIndex) });
        //                }
        //                parts.Add(new CodeBlock
        //                {
        //                    Language = match.Groups[1].Value,
        //                    Code = match.Groups[2].Value
        //                });
        //                lastIndex = match.Index + match.Length;
        //            }

        //            if (lastIndex < message.Length)
        //            {
        //                parts.Add(new TextContent { Text = message.Substring(lastIndex) });
        //            }

        //            return parts;
        //        }

        //        private void ViewCodeBlock_Click(object sender, RoutedEventArgs e)
        //        {
        //            var button = (Button)sender;
        //            var codeBlock = (CodeBlock)button.Tag;
        //            DisplayCodeBlock(codeBlock);
        //        }

        //        private void DisplayCodeBlock(CodeBlock codeBlock)
        //        {
        //            CodeEditor.Text = codeBlock.Code;
        //            CodeEditor.SyntaxHighlighting = customHighlighting;
        //            LeftColumn.Width = new GridLength(0);
        //            ChatColumn.Width = new GridLength(1, GridUnitType.Star);
        //            CodeColumn.Width = new GridLength(1, GridUnitType.Star);
        //        }
        //        private async void SendButton_Click(object sender, RoutedEventArgs e)
        //        {
        //            await SendMessage();
        //        }
        //        private string MapLanguageToAvalonEdit(string language)
        //        {
        //            switch (language.ToLower())
        //            {
        //                case "csharp":
        //                case "c#":
        //                    return "C#";
        //                case "xml":
        //                case "xaml":
        //                    return "XML";
        //                case "sql":
        //                    return "SQL";
        //                case "python":
        //                    return "Python";
        //                // Add more mappings as needed
        //                default:
        //                    return "C#"; // Default to C# highlighting if unknown
        //            }
        //        }
        //       private void CopyButton_Click(object sender, RoutedEventArgs e)
        //        {
        //            try
        //            {
        //                Clipboard.SetText(CodeEditor.Text);
        //            }
        //            catch (Exception ex)
        //            {
        //                MessageBox.Show($"Failed to copy code: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        //            }
        //        }
        //        private void CloseCodeBlock_Click(object sender, RoutedEventArgs e)
        //        {
        //            HideCodeBlock();
        //        }

        //        private void HideCodeBlock()
        //        {
        //            LeftColumn.Width = new GridLength(1, GridUnitType.Star);
        //            ChatColumn.Width = new GridLength(2, GridUnitType.Star);
        //            CodeColumn.Width = new GridLength(0);
        //        }
        //    }
        //    public static class TokenCounter
        //    {
        //        public static int EstimateTokenCount(string text)
        //        {
        //            return text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
        //        }
        //    }
        //    public class ChatMessage : INotifyPropertyChanged
        //    {
        //        private bool _isUser;
        //        private string _sender;
        //        private List<object> _content;
        //        private bool _isLoading;

        //        public bool IsUser
        //        {
        //            get => _isUser;
        //            set { _isUser = value; OnPropertyChanged(); }
        //        }

        //        public string Sender
        //        {
        //            get => _sender;
        //            set { _sender = value; OnPropertyChanged(); }
        //        }

        //        public List<object> Content
        //        {
        //            get => _content;
        //            set { _content = value; OnPropertyChanged(); }
        //        }

        //        public bool IsLoading
        //        {
        //            get => _isLoading;
        //            set { _isLoading = value; OnPropertyChanged(); }
        //        }

        //        public event PropertyChangedEventHandler PropertyChanged;

        //        protected virtual void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string propertyName = null)
        //        {
        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //        }
        //    }

        //    public class CodeBlock
        //    {
        //        public string Language { get; set; }
        //        public string Code { get; set; }
        //    }

        //    public class BoolToBackgroundConverter : IValueConverter
        //    {
        //        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        //        {
        //            if (value is bool isUser)
        //            {
        //                return isUser ? Application.Current.Resources["UserMessageBrush"]
        //                              : Application.Current.Resources["AIMessageBrush"];
        //            }
        //            return Application.Current.Resources["AIMessageBrush"];
        //        }

        //        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        //        {
        //            throw new NotImplementedException();
        //        }
        //    }

        //    public class SimpleConsoleLogger : ILogger
        //    {
        //        public IDisposable BeginScope<TState>(TState state) => null;

        //        public bool IsEnabled(LogLevel logLevel) => true;

        //        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        //        {
        //            if (!IsEnabled(logLevel))
        //            {
        //                return;
        //            }

        //            Console.WriteLine($"[{logLevel}] {formatter(state, exception)}");
        //        }
        //    }
        //    public class CodeBlockConverter : IValueConverter
        //    {
        //        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        //        {
        //            if (!(value is string message))
        //                return null;

        //            var parts = new List<object>();
        //            var regex = new Regex(@"```(\w+)\n([\s\S]*?)```");
        //            int lastIndex = 0;

        //            foreach (Match match in regex.Matches(message))
        //            {
        //                if (match.Index > lastIndex)
        //                {
        //                    parts.Add(new TextContent { Text = message.Substring(lastIndex, match.Index - lastIndex) });
        //                }
        //                parts.Add(new CodeBlock
        //                {
        //                    Language = match.Groups[1].Value,
        //                    Code = match.Groups[2].Value
        //                });
        //                lastIndex = match.Index + match.Length;
        //            }

        //            if (lastIndex < message.Length)
        //            {
        //                parts.Add(new TextContent { Text = message.Substring(lastIndex) });
        //            }

        //            return parts;
        //        }

        //        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        //        {
        //            throw new NotImplementedException();
        //        }
        //    }

        //    public class TextContent
        //    {
        //        public string Text { get; set; }
        //    }
        //}

    }
}
