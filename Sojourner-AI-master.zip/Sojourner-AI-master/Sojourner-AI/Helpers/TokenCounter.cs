﻿using System;

namespace Sojourner_AI
{
    public static class TokenCounter
    {
        public static int EstimateTokenCount(string text)
        {
            return text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }
    }
}