﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Sojourner_AI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Ensure WebView2 runtime is available
            try
            {
                var env = Microsoft.Web.WebView2.Core.CoreWebView2Environment.GetAvailableBrowserVersionString();
                if (string.IsNullOrEmpty(env))
                {
                    MessageBox.Show(
                        "WebView2 Runtime is not installed. Please install it to enable web scraping.",
                        "Missing Requirement",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error checking WebView2 Runtime: " + ex.Message,
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }
    }
}