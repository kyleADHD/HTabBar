﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;

namespace Sojourner_AI
{
    public class BoolToBackgroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isUser)
            {
                return isUser ? Application.Current.Resources["UserMessageBrush"]
                              : Application.Current.Resources["AIMessageBrush"];
            }
            return Application.Current.Resources["AIMessageBrush"];
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class CodeBlockConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!(value is string message))
                return null;

            var parts = new List<object>();
            var regex = new Regex(@"```(\w+)\n([\s\S]*?)```");
            int lastIndex = 0;

            foreach (Match match in regex.Matches(message))
            {
                if (match.Index > lastIndex)
                {
                    parts.Add(new TextContent { Text = message.Substring(lastIndex, match.Index - lastIndex) });
                }
                parts.Add(new CodeBlock
                {
                    Language = match.Groups[1].Value,
                    Code = match.Groups[2].Value
                });
                lastIndex = match.Index + match.Length;
            }

            if (lastIndex < message.Length)
            {
                parts.Add(new TextContent { Text = message.Substring(lastIndex) });
            }

            return parts;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}