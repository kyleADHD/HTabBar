﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Sojourner_AI
{
    public class ChatMessage : INotifyPropertyChanged
    {
        private bool _isUser;
        private string _sender;
        private List<object> _content;
        private bool _isLoading;

        public bool IsUser
        {
            get => _isUser;
            set { _isUser = value; OnPropertyChanged(); }
        }

        public string Sender
        {
            get => _sender;
            set { _sender = value; OnPropertyChanged(); }
        }

        public List<object> Content
        {
            get => _content;
            set { _content = value; OnPropertyChanged(); }
        }

        public bool IsLoading
        {
            get => _isLoading;
            set { _isLoading = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}