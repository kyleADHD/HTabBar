﻿namespace Sojourner_AI
{
    public class CodeBlock
    {
        public string Title { get; set; }
        public string Language { get; set; }
        public string Code { get; set; }
        public CodeBlock()
        {
            Title = "Code Snippet";  
        }
    }
}