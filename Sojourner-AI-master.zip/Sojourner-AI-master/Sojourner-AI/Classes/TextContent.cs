﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sojourner_AI
{
    public class TextContent
    {
        public string Text { get; set; }
    }
}
