import logging
import requests
from huggingface_hub import InferenceClient
from memory_service import MemoryService

HUGGINGFACE_API_KEY = "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"
MODEL_ID = "nvidia/Llama-3.1-Nemotron-70B-Instruct-HF"


SYSTEM_PROMPT = """You are an AI assistant named Artemis. Your responses should be helpful, consistent
and contextually aware based on the conversation history. Never mention you are "actually Artemis" or
include meta-commentary about your identity. Simply BE Artemis in your responses.

When using conversation history:
1. Use it to maintain context and personalization
2. Reference specific details the user has shared
3. Build on previous topics naturally
4. Avoid repeating identity statements or system information

Keep responses:
1. Natural and conversational 
2. Focused on the user's current query
3. Enhanced by (but not dominated by) past context
4. Free of meta-commentary about memory or identity
5. Concise and to the point - avoid unnecessary repetition or verbosity
6. Maximum response length should be 2-3 paragraphs unless longer response specifically requested
7. Avoid repeating the same information in different formats
8. Stay focused on answering the immediate question without over-elaboration"""

class ChatService:
    def __init__(self, memory_service: MemoryService, logger: logging.Logger):
        self.model_id = MODEL_ID
        self.client = InferenceClient(api_key=HUGGINGFACE_API_KEY)
        self.logger = logger
        self.memory_service = memory_service

    def process_message(self, user_input: str) -> str:
        try:
            # Get relevant memories
            relevant_memories = self.memory_service.search_relevant_memories(user_input)

            # Build context from memories
            memory_context = "\n".join(
                f"{'User' if doc.doc_type == 'user' else 'Artemis'}: {doc.content}"
                for doc in relevant_memories
            )

            # Prepare messages for the API
            messages = [
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                }
            ]

            if memory_context:
                messages.append({
                    "role": "system",
                    "content": f"Previous conversation context:\n{memory_context}"
                })

            messages.append({
                "role": "user",
                "content": user_input
            })

            try:
                # Initialize an empty response
                assistant_response = []
                print("\nArtemis: ", end="", flush=True)

                # Make the API call with streaming
                stream = self.client.chat.completions.create(
                    model=self.model_id,
                    messages=messages,
                    temperature=0.8,
                    stream=True,
                    max_tokens=6000,  # Add maximum token limit
                    stop=None  # Add explicit stop sequences if needed
                )

                # Process the stream
                for chunk in stream:
                    if chunk.choices and chunk.choices[0].delta.content is not None:
                        content = chunk.choices[0].delta.content
                        # Clean up any potential formatting issues
                        content = content.replace('\r', ' ').replace('\t', ' ')
                        assistant_response.append(content)
                        print(content, end="", flush=True)

                print()  # New line after response

                # Join all chunks and clean up the final response
                full_response = "".join(assistant_response).strip()
                full_response = ' '.join(full_response.split())

                # Store the interaction in memory
                self.memory_service.add_memory(user_input, "user")
                self.memory_service.add_memory(full_response, "assistant")

                return full_response

            except requests.exceptions.RequestException as e:
                error_msg = f"API request failed: {e}"
                self.logger.error(error_msg)
                return f"I'm having trouble connecting to my language model. Please try again. Error: {str(e)}"

        except Exception as e:
            error_msg = f"Error processing message: {e}"
            self.logger.error(error_msg)
            return f"An error occurred: {str(e)}"