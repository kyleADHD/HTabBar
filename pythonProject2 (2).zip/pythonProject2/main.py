import logging
from memory_service import MemoryService, DB_PATH
from Communication import ChatService, HUGGINGFACE_API_KEY, MODEL_ID

def main():
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)

    # Verify API key is set
    if HUGGINGFACE_API_KEY == "your_api_key_here":
        print("Please set your Hugging Face API key as an environment variable HUGGINGFACE_API_KEY")
        return

    try:
        # Initialize services
        memory_service = MemoryService(DB_PATH, logger)
        chat_service = ChatService(memory_service, logger)

        print("\nChat Application Started!")
        print("Using model:", MODEL_ID)
        print("\nThis chat bot automatically remembers conversation history and uses it for context.")
        print("Type 'exit' to quit or 'clear' to clear the screen.")
        print("\nReady to chat with Artemis!")

        while True:
            try:
                user_input = input("\nYou: ").strip()

                if not user_input:
                    continue

                if user_input.lower() == 'exit':
                    break

                if user_input.lower() == 'clear':
                    print('\033[2J\033[H')
                    continue

                response = chat_service.process_message(user_input)

            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"\nError: {e}")
                logger.exception("Error in main loop")

    except Exception as e:
        logger.error(f"Application startup failed: {e}")
        print(f"\nFailed to start application: {e}")

if __name__ == "__main__":
    main()