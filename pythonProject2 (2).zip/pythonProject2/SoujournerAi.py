import sqlite3
import logging
import numpy as np
from datetime import datetime, UTC, timezone
import requests
from typing import List, Dict, Any
import json
from dataclasses import dataclass
import uuid
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from huggingface_hub import InferenceClient

# Configuration - Set this as environment variable
HUGGINGFACE_API_KEY = "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"
MODEL_ID = "nvidia/Llama-3.1-Nemotron-70B-Instruct-HF"
DB_PATH = "chat_memory.db"
MAX_MEMORIES = 1000  # Maximum number of memories to keep

SYSTEM_PROMPT = """You are an AI assistant named Artemis. Your responses should be helpful, consistent
and contextually aware based on the conversation history. Never mention you are "actually Artemis" or
include meta-commentary about your identity. Simply BE Artemis in your responses.

When using conversation history:
1. Use it to maintain context and personalization
2. Reference specific details the user has shared
3. Build on previous topics naturally
4. Avoid repeating identity statements or system information

Keep responses:
1. Natural and conversational 
2. Focused on the user's current query
3. Enhanced by (but not dominated by) past context
4. Free of meta-commentary about memory or identity"""


@dataclass
class Document:
    id: str
    content: str
    doc_type: str
    metadata: str
    created: datetime
    vector: np.ndarray

    @classmethod
    def create(cls, content: str, doc_type: str, metadata: str = None):
        return cls(
            id=str(uuid.uuid4()),
            content=content,
            doc_type=doc_type,
            metadata=metadata,
            created=datetime.now(timezone.utc),  # Use timezone.utc instead of UTC
            vector=None
        )


class MemoryService:
    def __init__(self, db_path: str, logger: logging.Logger):
        self.logger = logger
        self.db_path = db_path
        self.vectorizer = None
        self.conn = self._initialize_database()

        # Use consistent datetime adapters
        def adapt_datetime(val):
            return val.isoformat() if val else None

        def convert_datetime(val):
            return datetime.fromisoformat(val.decode()) if val else None

        sqlite3.register_adapter(datetime, adapt_datetime)
        sqlite3.register_converter("timestamp", convert_datetime)

    def _initialize_database(self) -> sqlite3.Connection:
        """Initialize SQLite database with required tables"""
        try:
            conn = sqlite3.connect(
                self.db_path,
                detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
            )

            # Enable foreign keys
            conn.execute("PRAGMA foreign_keys = ON")

            cursor = conn.cursor()

            cursor.executescript("""
                CREATE TABLE IF NOT EXISTS documents (
                    id TEXT PRIMARY KEY,
                    content TEXT NOT NULL,
                    type TEXT NOT NULL,
                    metadata TEXT,
                    created timestamp NOT NULL DEFAULT (datetime('now'))
                );

                CREATE TABLE IF NOT EXISTS vectors (
                    document_id TEXT PRIMARY KEY,
                    vector BLOB NOT NULL,
                    FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
                );

                CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts 
                USING fts5(content, type, metadata);

                -- Add indexes for better performance
                CREATE INDEX IF NOT EXISTS idx_documents_created ON documents(created);
                CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type);
            """)

            conn.commit()
            return conn

        except Exception as e:
            self.logger.error(f"Database initialization failed: {e}")
            raise

    def _initialize_vectorizer(self, text: str) -> np.ndarray:
        """Initialize or update the vectorizer with text"""
        try:
            # Get existing documents
            cursor = self.conn.cursor()
            cursor.execute("SELECT content FROM documents ORDER BY created DESC LIMIT ?", (MAX_MEMORIES,))
            documents = [row[0] for row in cursor.fetchall()]

            # Add new text to documents
            if text not in documents:
                documents.append(text)

            # Create new vectorizer and fit on all documents
            self.vectorizer = TfidfVectorizer(min_df=1, stop_words=None)
            self.vectorizer.fit(documents)

            # Transform the new text
            return self.vectorizer.transform([text]).toarray()[0]

        except Exception as e:
            self.logger.error(f"Vectorizer initialization failed: {e}")
            raise

    def search_relevant_memories(self, query: str, k: int = 5) -> List[Document]:
        """Search for relevant memories based on the query"""
        try:
            cursor = self.conn.cursor()

            # Get recent documents with their vectors
            cursor.execute("""
                SELECT d.id, d.content, d.type, d.metadata, d.created, v.vector
                FROM documents d
                JOIN vectors v ON d.id = v.document_id
                ORDER BY d.created DESC
                LIMIT ?
            """, (max(k * 2, 10),))

            stored_docs = cursor.fetchall()

            if not stored_docs:
                return []

            if not self.vectorizer:
                # Initialize vectorizer with existing documents
                all_contents = [doc[1] for doc in stored_docs]
                self.vectorizer = TfidfVectorizer(min_df=1, stop_words=None)
                self.vectorizer.fit(all_contents)

            # Get query vector
            try:
                query_vector = self.vectorizer.transform([query]).toarray()[0]
            except Exception as e:
                self.logger.error(f"Error transforming query: {e}")
                # Reinitialize vectorizer and try again
                query_vector = self._initialize_vectorizer(query)

            results = []
            for row in stored_docs:
                doc_vector = np.frombuffer(row[5], dtype=np.float64)

                # Handle vector dimension mismatch
                if len(doc_vector) != len(query_vector):
                    self._update_all_vectors()
                    return self.search_relevant_memories(query, k)

                similarity = cosine_similarity([query_vector], [doc_vector])[0][0]

                doc = Document(
                    id=row[0],
                    content=row[1],
                    doc_type=row[2],
                    metadata=row[3],
                    created=row[4],
                    vector=doc_vector
                )
                results.append((similarity, doc))

            # Sort by combination of similarity and recency
            results.sort(key=lambda x: (x[0], x[1].created), reverse=True)
            return [doc for _, doc in results[:k]]

        except Exception as e:
            self.logger.error(f"Error searching memories: {e}")
            return []

    def add_memory(self, content: str, role: str, metadata: str = None) -> None:
        """Add a new memory to the database"""
        try:
            # Filter system statements if it's an assistant response
            if role == "assistant":
                content = self._filter_system_statements(content)

            # Create document
            doc = Document.create(content, role, metadata)

            # Get or create vector
            if self.vectorizer is None:
                vector = self._initialize_vectorizer(content)
            else:
                vector = self.vectorizer.transform([content]).toarray()[0]
            doc.vector = vector

            cursor = self.conn.cursor()

            try:
                cursor.execute("BEGIN TRANSACTION")

                # Insert document
                cursor.execute(
                    "INSERT INTO documents (id, content, type, metadata, created) VALUES (?, ?, ?, ?, ?)",
                    (doc.id, doc.content, doc.doc_type, doc.metadata, doc.created)
                )

                # Store vector
                cursor.execute(
                    "INSERT INTO vectors (document_id, vector) VALUES (?, ?)",
                    (doc.id, doc.vector.tobytes())
                )

                # Update FTS table
                cursor.execute(
                    "INSERT INTO documents_fts (content, type, metadata) VALUES (?, ?, ?)",
                    (doc.content, doc.doc_type, doc.metadata)
                )

                cursor.execute("COMMIT")

            except Exception as e:
                cursor.execute("ROLLBACK")
                raise e

            # Cleanup after successful addition
            self.cleanup_database()

        except Exception as e:
            self.logger.error(f"Error adding memory: {e}")
            raise

    def _update_all_vectors(self) -> None:
        """Update all document vectors using current vectorizer"""
        try:
            cursor = self.conn.cursor()

            # Get all documents
            cursor.execute("""
                SELECT id, content 
                FROM documents 
                ORDER BY created DESC 
                LIMIT ?
            """, (MAX_MEMORIES,))

            documents = cursor.fetchall()

            if not documents:
                return

            # Initialize vectorizer with all documents
            contents = [doc[1] for doc in documents]
            self.vectorizer = TfidfVectorizer(min_df=1, stop_words=None)
            self.vectorizer.fit(contents)

            try:
                cursor.execute("BEGIN TRANSACTION")

                # Update vectors for all documents
                for doc_id, content in documents:
                    vector = self.vectorizer.transform([content]).toarray()[0]

                    # Delete old vector if exists
                    cursor.execute(
                        "DELETE FROM vectors WHERE document_id = ?",
                        (doc_id,)
                    )

                    # Insert new vector
                    cursor.execute(
                        "INSERT INTO vectors (document_id, vector) VALUES (?, ?)",
                        (doc_id, vector.tobytes())
                    )

                cursor.execute("COMMIT")

            except Exception as e:
                cursor.execute("ROLLBACK")
                raise e

        except Exception as e:
            self.logger.error(f"Vector update failed: {e}")
            raise

    def cleanup_database(self) -> None:
        """Clean up old memories keeping only the most recent ones"""
        try:
            cursor = self.conn.cursor()

            try:
                cursor.execute("BEGIN TRANSACTION")

                # Get IDs of documents to keep
                cursor.execute("""
                    SELECT id FROM documents 
                    ORDER BY created DESC 
                    LIMIT ?
                """, (MAX_MEMORIES,))

                keep_ids = {row[0] for row in cursor.fetchall()}

                if not keep_ids:
                    cursor.execute("ROLLBACK")
                    return

                # Delete old vectors (CASCADE will handle this automatically)
                cursor.execute("""
                    DELETE FROM documents 
                    WHERE id NOT IN ({})
                """.format(','.join('?' * len(keep_ids))), tuple(keep_ids))

                # Clean up FTS table
                cursor.execute("DELETE FROM documents_fts WHERE rowid NOT IN (SELECT rowid FROM documents)")

                cursor.execute("COMMIT")

            except Exception as e:
                cursor.execute("ROLLBACK")
                raise e

        except Exception as e:
            self.logger.error(f"Database cleanup failed: {e}")
            raise

    def _filter_system_statements(self, content: str) -> str:
        """Remove system statements and identity commentary from assistant responses"""
        filtered_lines = []
        skip_line = False

        for line in content.split('\n'):
            # Skip lines containing system/identity statements
            if any(phrase in line.lower() for phrase in [
                "remember, if you ever ask",
                "reminder:",
                "i am artemis",
                "conversation history update",
                "current knowledge base",
                "**remember**",
                "**reminder:**"
            ]):
                skip_line = True
                continue

            if not skip_line:
                filtered_lines.append(line)
            skip_line = False

        return '\n'.join(filtered_lines).strip()

    def __del__(self):
        """Clean up database connection on deletion"""
        if hasattr(self, 'conn'):
            try:
                self.conn.close()
            except Exception as e:
                self.logger.error(f"Error closing database connection: {e}")


class ChatService:
    def __init__(self, memory_service: MemoryService, logger: logging.Logger):
        self.model_id = MODEL_ID
        self.client = InferenceClient(api_key=HUGGINGFACE_API_KEY)
        self.logger = logger
        self.memory_service = memory_service

    def process_message(self, user_input: str) -> str:
        try:
            # Get relevant memories
            relevant_memories = self.memory_service.search_relevant_memories(user_input)

            # Build context from memories
            memory_context = "\n".join(
                f"{'User' if doc.doc_type == 'user' else 'Artemis'}: {doc.content}"
                for doc in relevant_memories
            )

            # Prepare messages for the API
            messages = [
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                }
            ]

            if memory_context:
                messages.append({
                    "role": "system",
                    "content": f"Previous conversation context:\n{memory_context}"
                })

            messages.append({
                "role": "user",
                "content": user_input
            })

            try:
                stream = self.client.chat.completions.create(
                    model=self.model_id,
                    messages=messages,
                    temperature=0.7,
                    stream=True,
                    stop=["\n\n", "User:", "Artemis:"]  # Prevent response bleeding
                )

                assistant_response = ""
                print("\nArtemis: ", end="", flush=True)

                # Improved streaming handling
                for chunk in stream:
                    if chunk.choices[0].delta.content is not None:
                        content = chunk.choices[0].delta.content
                        # Clean up any potential formatting issues
                        content = content.replace('\r', ' ').replace('\t', ' ')
                        assistant_response += content
                        print(content, end="", flush=True)

                print()

                # Clean up the final response
                assistant_response = assistant_response.strip()

                # Post-process to ensure clean formatting
                assistant_response = ' '.join(assistant_response.split())

                # Store the interaction in memory
                self.memory_service.add_memory(user_input, "user")
                self.memory_service.add_memory(assistant_response, "assistant")

                return assistant_response

            except requests.exceptions.RequestException as e:
                self.logger.error(f"API request failed: {e}")
                return "I'm having trouble connecting to my language model. Please try again."

        except Exception as e:
            self.logger.error(f"Error processing message: {e}")
            return f"Error: {str(e)}"


def main():
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)

    # Verify API key is set
    if HUGGINGFACE_API_KEY == "your_api_key_here":
        print("Please set your Hugging Face API key as an environment variable HUGGINGFACE_API_KEY")
        return

    try:
        # Initialize services
        memory_service = MemoryService(DB_PATH, logger)
        chat_service = ChatService(memory_service, logger)

        print("\nChat Application Started!")
        print("Using model:", MODEL_ID)
        print("\nThis chat bot automatically remembers conversation history and uses it for context.")
        print("Type 'exit' to quit or 'clear' to clear the screen.")
        print("\nReady to chat with Artemis!")

        while True:
            try:
                user_input = input("\nYou: ").strip()

                if not user_input:
                    continue

                if user_input.lower() == 'exit':
                    break

                if user_input.lower() == 'clear':
                    print('\033[2J\033[H')
                    continue

                response = chat_service.process_message(user_input)

            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"\nError: {e}")
                logger.exception("Error in main loop")

    except Exception as e:
        logger.error(f"Application startup failed: {e}")
        print(f"\nFailed to start application: {e}")


if __name__ == "__main__":
    main()