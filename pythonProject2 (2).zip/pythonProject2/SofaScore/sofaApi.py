import json

from selenium import webdriver # selenium 4.20.0
from selenium.webdriver.chrome.service import Service as ChromeService

from webdriver_manager.chrome import ChromeDriverManager # version 4.0.1

options = webdriver.ChromeOptions()
options.set_capability(
    "goog:loggingPrefs", {"performance": "ALL", "browser": "ALL"}
)

# Make sure you already have Chrome installed
driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)
driver.set_page_load_timeout(10)

try:
    driver.get("https://www.sofascore.com/inter-miami-cf-new-york-red-bulls/gabsccKc#id:11911622,tab:statistics")
except:
    pass


driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

logs_raw = driver.get_log("performance")
logs = [json.loads(lr["message"])["message"] for lr in logs_raw]