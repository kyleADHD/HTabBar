# Install the Twilio helper library with: pip install twilio
from twilio.rest import Client
import json
import os

# Replace these placeholders with your actual Account SID and Auth Token from twilio.com/console
# For security, it's best to set these as environment variables
account_sid = 'AC2f2a7bdcc467a9b08dec4cc021f22252'
auth_token = '8f9cb2201fac56a75e7ec416e030c96e'      # e.g., 'your_auth_token'

# Alternatively, use environment variables for security
# account_sid = os.environ.get('TWILIO_ACCOUNT_SID')
# auth_token = os.environ.get('TWILIO_AUTH_TOKEN')

# Initialize the Twilio client
client = Client(account_sid, auth_token)

# Define your Content Template SID
content_sid = 'HX5c14a25235fb09cc316b86082606815c'  # Replace with your actual Content SID

# Prepare the content variables for the template
content_variables = json.dumps({
    "1": "Test User",
    "2": "Test Consultant",
    "3": "VNBMPMSJ",
    "4": ""
})

# Send the message
try:
    message = client.messages.create(
        content_sid=content_sid,
        content_variables=content_variables,
        from_='whatsapp:+27648481290',  # Replace with your Twilio WhatsApp-enabled number
        to='whatsapp:+27828233657',      # Replace with the recipient's WhatsApp number
        body=None  # Explicitly set body to None to avoid conflict with content_sid
    )
    # Print the SID of the sent message
    print(f"Message SID: {message.sid}")
    print("Message sent successfully.")
except Exception as e:
    print(f"Failed to send message: {e}")
